<!DOCTYPE html>
<html>
<head>
  <title>深信崖云Beta</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./css/bootstrap.min.css">  
  <script src="./jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
 <!--  <script type="text/javascript">
	  alert("欢迎使用深信崖云Beta系统，本系统原先包含系统渗透，抓包理论，web安全，但由于大量的代码及数据库连接导致本UP主脑子短路..所以只保留了web安全这一个模块，另外先声明下，web安全这个模块是由多个sql注入页面拼合起来的，过几天会自己写几个页面进去，有时间在做教程...好了就这样Enjoy this!另外B站：冰崖mua | 技术交流群：516265094")
	  
  </script> -->
</head>
<body>
<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column">
			<nav class="navbar navbar-default navbar-inverse" role="navigation">
				<div class="navbar-header">
					 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button> <a class="navbar-brand" href="#">深信崖云Beta</a>
				</div>
				
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						
						<li class="active">
							 <a href="#">主页</a>
						</li>
						<li>
							 <a href="#">系统渗透</a>
						</li>
						<li>
							 <a href="#">Web安全</a>
						</li>
						<li>
							 <a href="#">抓包训练</a>
						</li>
						<li>
							 <a href="#">待开发...</a>
						</li>
						<li class="dropdown">
							 <a href="#" class="dropdown-toggle" data-toggle="dropdown">虚拟机启停<strong class="caret"></strong></a>
							<ul class="dropdown-menu">
								<li>
									 <a href="#">Action</a>
								</li>
								<li>
									 <a href="#">Another action</a>
								</li>
								<li>
									 <a href="#">Something else here</a>
								</li>
								<li class="divider">
								</li>
								<li>
									 <a href="#">Separated link</a>
								</li>
								<li class="divider">
								</li>
								<li>
									 <a href="#">One more separated link</a>
								</li>
							</ul>
						</li>
					</ul>
					<form class="navbar-form navbar-left" role="search">
						<div class="form-group">
							<input type="text" class="form-control" />
						</div> <button type="submit" class="btn btn-default" href="http://192.168.209.135:65535/phpMyAdmin">确定</button>
					</form>
					<ul class="nav navbar-nav navbar-right">
						<li>
							 <a href="http://192.168.209.135:65535/phpMyAdmin" target="_blank">phpMyAdmin</a>
						</li>
						
					</ul>
				</div>
				
			</nav>
			<marquee>最近更新：2019年5月16日 更新内容：web安全模块 asp+access注入13个站点 php+mysql注入20个站点</marquee>
			<div class="jumbotron well">
				<h1>
					欢迎来到深信崖云！<img src="./img/logo_cliff.png" style="height:20px;width:120px;" align="center">
				</h1>

				<p>
					 <a class="btn btn-primary btn-large"  onclick="alert("这是一个非常无聊的渗透测试系统，由非常无聊的冰崖团队编写(hb，实际上就我一个人QAQ)，该系统仅用于企业及学校内测，不用于商业，在正式版出来之后将会进行1.0.0~1.0.1递归发布~")">免责声明</a>
					 <button class="btn btn-primary btn-large">环境测试</button>
					 
				</p>
			</div>
			<div class="row clearfix">
				<div class="col-md-8 column">
					<div class="page-header">
						<h1>
							开始我们的渗透之旅吧！ <small>请遵守网络安全法，否则...</small>
						</h1>
					</div>
					<h2>
						免责声明
					</h2>
					<!-- <p>
						该系统完全是UP主脑子一热一时兴起所写出来的，该系统由php+mysql进行编写mysql用于存放flag等等...，界面采用bootstrap,虚拟机启停采用某云vnc连接,由于UP主还在上学所以只写了web安全这个板块，另外这个web安全是由各种sql注入拼合起来的一个环境，不喜勿喷，希望各位大牛不要喷我，本人仅是小白一枚...
					</p> -->
					<p>
						 <a class="btn" href="#">View details »</a>
					</p>
					<table class="table table-condensed table-hover table-bordered">
						<thead>
							<tr>
								<th>
									编号
								</th>
								<th>
									虚拟机名
								</th>
								<th>
									开机时间
								</th>
								<th>
									开机状态
								</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									1
								</td>
								<td>
									Windows-Server-2003(web安全)
								</td>
								<td>
									**-**-**
								</td>
								<td style="color: red;font: bold;">
									Open
									<button type="button" class="btn btn-default" style="font-size: 10px;">关闭</button><button type="button" class="btn btn-default" style="font-size: 10px;">连接</button>
								</td>
							</tr>
							<tr class="info">
								<td>
									2
								</td>
								<td>
									Windows-Server-2008(web安全)
								</td>
								<td>
									00:00:00
								</td>
								<td>
									Disable
									<button type="button" class="btn btn-default" style="font-size: 10px;">开启</button>
								</td>
								
							</tr>
							<tr class="info">
								<td>
									3
								</td>
								<td>
									Kali-2.0(攻击机1)
								</td>
								<td>
									00:00:00
								</td>
								<td>
									Disable
									<button type="button" class="btn btn-default" style="font-size: 10px;">开启</button>
								</td>
							</tr>
							<tr class="info">
								<td>
									4
								</td>
								<td>
									Kali-1.0(攻击机2)
								</td>
								<td>
									00:00:00
								</td>
								<td>
									Disable
									<button type="button" class="btn btn-default" style="font-size: 10px;">开启</button>
								</td>
							</tr>
							<tr class="info">
								<td>
									5
								</td>
								<td>
									BT5-A1(攻击机3)
								</td>
								<td>
									00:00:00
								</td>
								<td>
									Disable
									<button type="button" class="btn btn-default" style="font-size: 10px;">开启</button>
								</td>
							
							</tr>
							<tr class="info">
								<td>
									6
								</td>
								<td>
									CentOS-7(靶机1)
								</td>
								<td>
									00:00:00
								</td>
								<td>
									Disable
									<button type="button" class="btn btn-default" style="font-size: 10px;">开启</button>
								</td>
							
							</tr>
						</tbody>
					</table>
					<div class="row clearfix">
						<div class="col-md-12 column">
							<h2>
								Web安全模块
							</h2>
							<p>
								所有的环境全部都是网上下载sql注入源码！！！不是自己写的！！！过几天会自己写一套出来，有空在做教程....
							</p>
							<p>
								 <a class="btn" href="#">晓得咯»</a>
							</p>
							<h3>
								asp+access注入环境(v1.0.0.0)
							</h3>
							<ul>
								<li>
									<a href="http://192.168.209.135:12354" target="_blank">测试站点1</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12347" target="_blank">测试站点2</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12351" target="_blank">测试站点3</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12349" target="_blank">测试站点4</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12345" target="_blank">测试站点5</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12352" target="_blank">测试站点6</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12353" target="_blank">测试站点7</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12350" target="_blank">测试站点8</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12355" target="_blank">测试站点9</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12357" target="_blank">测试站点10</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12348" target="_blank">测试站点11</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12346" target="_blank">测试站点12</a>
								</li>
								<li>
									<a href="http://192.168.209.135:12356" target="_blank">测试站点13</a>
								</li>
							</ul>
							<h3>
								php+mysql注入环境(v1.0.0.0)
							</h3>
							<ul>
								<li>
									<a href="http://192.168.209.135:65535/bbs_luntan" target="_blank">测试站点1</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/caihong" target="_blank">测试站点2</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/cms-master" target="_blank">测试站点3</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/dvwa(1.0.7)" target="_blank">测试站点4</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/luntan" target="_blank">测试站点5</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/metinfo5.0" target="_blank">测试站点6</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/mysqlback" target="_blank">测试站点7</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/phpcmsv9" target="_blank">测试站点8</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/pikachu-master" target="_blank">测试站点9</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/social" target="_blank">测试站点10</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/sqli-labs-master" target="_blank">测试站点11</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/sqlmapgui" target="_blank">测试站点12</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/twoinjection" target="_blank">测试站点13</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/upload" target="_blank">测试站点14</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/websitedos" target="_blank">测试站点15</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/xss" target="_blank">测试站点16</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/xss2" target="_blank">测试站点17</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/yiku" target="_blank">测试站点18</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/ZVulDrill" target="_blank">测试站点19</a>
								</li>
								<li>
									<a href="http://192.168.209.135:65535/ZVulDrill(asd*)" target="_blank">测试站点20</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 column">
					<div class="alert alert-dismissable alert-danger">
						 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						<h4>
							警告!
						</h4> <strong>数据库连接出错！</strong> 数据库连接失败，请检查config.php配置文件 <a href="#" class="alert-link">一般出错</a>
					</div>

					<?php
					if('/'==DIRECTORY_SEPARATOR){
    					$server_ip=$_SERVER['SERVER_ADDR'];
					}else{
    					$server_ip=@gethostbyname($_SERVER['SERVER_NAME']);
					}
					if('/'==DIRECTORY_SEPARATOR){
						$server_port=$_SERVER['REMOTE_PORT'];
					}else{
						$server_port=@gethostbyname($_SERVER['REMOTE_PORT']);
					}
					if('/'==DIRECTORY_SEPARATOR){
						$server_port_port=$_SERVER['SERVER_PORT'];
					}else{
						$server_port_port=@gethostbyname($_SERVER['SERVER_PORT']);
					}
					if('/'==DIRECTORY_SEPARATOR){
						$server_language=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
					}else{
						$server_language=@gethostbyname($_SERVER['HTTP_ACCEPT_LANGUAGE']);
					}
					if('/'==DIRECTORY_SEPARATOR){
						$server_user_get=$_SERVER['HTTP_USER_AGENT'];
					}else{
						$server_user_get=@gethostbyname($_SERVER['HTTP_USER_AGENT']);
					}
					if('/'==DIRECTORY_SEPARATOR){
						$server_admin=$_SERVER['SERVER_PROTOCOL'];
					}else{
						$server_admin=@gethostbyname($_SERVER['SERVER_PROTOCOL']);
					}
					if('/'==DIRECTORY_SEPARATOR){
						$server_get=$_SERVER['REQUEST_METHOD'];
					}else{
						$server_get=@gethostbyname($_SERVER['REQUEST_METHOD']);
					}
				echo "
					<div class=\"alert alert-dismissable alert-success\">
						 <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
						<h4>
							崖云助手：
						</h4> <strong>系统IP：</strong>.$server_ip;
						<br><strong>系统端口：</strong>.$server_port_port;
						<br><strong>浏览器端口：</strong>.$server_port;
						<br><strong>请求方式：</strong>.$server_get;
						<br><strong>当前浏览器语言：</strong>.$server_language;
						<br><strong>请求内容：</strong>.$server_user_get;
						<br><strong>HTTP版本：</strong>.$server_admin;

					</div>";

					?>
					<!-- <div class="alert alert-success alert-dismissable">
						 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						<h4>
							注意!
						</h4> <strong>!</strong> Best check yo self, you're not looking too good. <a href="#" class="alert-link">alert link</a>
					</div>
					<div class="alert alert-success alert-dismissable">
						 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						<h4>
							注意!
						</h4> <strong>Warning!</strong> Best check yo self, you're not looking too good. <a href="#" class="alert-link">alert link</a>
					</div> -->
				</div>
			</div>
		</div>
	</div>
	<div class="alert alert-success alert-dismissable" align="center">
							 
							<h4 style="text-align: center;">
								©版权归冰崖网络所有 2012~2019 一个中学生的安全人生
							</h4> <strong style="text-align:center">B站：</strong>冰崖mua  <strong style="text-align:center">公众号：</strong>冰崖网络</h4> <strong style="text-align:center">微博：</strong>极客冰崖  <strong style="text-align:center">QQ群：</strong>516265094<a href="http://www.geekicecliffs.ml" class="alert-link">冰崖小站点</a>
						</div>
</div>

</body>
</html>